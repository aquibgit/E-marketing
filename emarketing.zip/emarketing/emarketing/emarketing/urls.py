"""
URL configuration for emarketing project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path,include
from . import views

urlpatterns = [
    path('',include('user_app.urls')),
    path('',include('seller_app.urls')),
    path('',include('admin_app.urls')),
    path('',views.index),
    path('login',views.login),
    path('register',views.register),
    path('logout',views.logout,name="logout"),
    path('registeraction',views.registeraction),
    path('seller_register',views.seller_register),
    path('seller_registeraction',views.seller_registeraction),
    path('sellerindex', views.sellerindex ,name="sellerindex"),
    path('adminindex',views.adminindex,name="adminindex"),
    path('index',views.adminindex)
]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
